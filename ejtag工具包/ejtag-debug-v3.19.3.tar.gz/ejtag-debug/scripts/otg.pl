#!/usr/bin/perl
use bignum;
unshift @INC,qq(./scripts);
require qq(io.pm);

$base = 0xffffffffbfe60000;
#inl($base+0xe4);

